# Aiogram-Template
Pythonda Aiogramdan foydalanib bot yaratish uchun shablon
